const toDoList = [];
let t, chwa = '', tach = '', endis = '', karakte = '1234567890=~!@#$%^&*+[]{}|"<>?/', kite = true, konfim = true, endisValab = true, mesaj = '';

function addTask(deskripsyonTach){
    toDoList.push(deskripsyonTach); 
}

function displayTask(){
    console.clear();
    for(let i = 0; i < toDoList.length; i++){
        console.log((i+1)+"- Tach "+toDoList[i]);
    }
}

function markTaskDone(endisTach){
    endisTach--;
    for(let i = 0; i < toDoList.length; i++){
        if(endisTach === i){
            // console.log("Tach "+toDoList[endisTach]);
            alert("Ou fini ak tach "+toDoList[endisTach]);
            toDoList.splice(endisTach, 1);
            break;
        }
    }
}
do{
    chwa = prompt("MENI PRENSIPAL \n1.- Ajoute tach. \n2.- Afiche tach yo."+
    "\n3.- Fini yon tach. \n4.- Fèmen");
    switch(parseInt(chwa)){
        case 1 :
            do{
                tach = prompt("Antre tach ou an la : Ekzanp 'Pwograme'");
                tach = tach[0].toUpperCase() + tach.substring(1);
                let endeks = toDoList.findIndex(tdl => tdl === tach);
                if(tach.length < 2){
                    mesaj = "Tach ou an dwe ekri ak 2 lèt pou pi piti !";
                    konfim = false;
                }else if(tach.length > 20){
                    mesaj = "Tach ou an dwe ekri ak 20 lèt pou pi plis !";
                    konfim = false;
                }else if(endeks >= 0){
                    mesaj = "Tach sa ekziste deja nan TodoList ou an !";
                    konfim = false;
                }else{
                    for(let k of tach){
                        if(karakte.includes(k)){
                            mesaj = "Tach ou an pa dwe gen ni chif ni karaktè spesyal !";
                            konfim = false;
                            break;
                        }else{
                            konfim = true;
                        }
                    }
                }
                if(konfim){
                    addTask(tach);
                    alert("Felisitasyon ! Ou ajoute yon tach.");
                }else{
                    alert(mesaj);
                }
            }while(!tach || !konfim);
            break;
        case 2 : 
            if(toDoList.length > 0){
                displayTask();
            }else{
                alert("Ou poko gen tach !");
            }
            break;
        case 3 :
            do{
                if(toDoList.length === 0){
                    alert("Ou poko gen tach nan TodoList ou an ");
                    endisValab = true;
                }else{
                    endis = prompt("Antre endis tach ou vle fini an : ");
                    if(endis >= (toDoList.length + 1) ){
                        alert("Endis ou antre an two gwo ! Chwazi yon endis devan tach ou yo !");
                        endisValab = false;
                    }else if(endis < 0){
                        alert("Ou antre yon endis negatif !");
                        endisValab = false;
                    }else{
                        t = toDoList[parseInt(endis)];
                        for(let e of endis){
                            if(!'0123456789'.includes(e)){
                                alert("Endis lan paka gen ni lèt ni karaktè spesyal ladan'l");
                                endisValab = false;
                            }else{
                                endisValab = true;
                            }
                        }
                    }
                    if(endisValab){
                        markTaskDone(parseInt(endis));
                        displayTask();
                    }
                }
            }while(!endisValab);

            break;
        case 4 :
            alert("Ou deside kite TodoList ou an !");
            kite = false;
            break;
        default :
            alert("Ou fè chwa yon meni ki pa ekziste ! ");
            break;
    }

}while(kite);
